// SPDX-FileCopyrightText: no
// SPDX-License-Identifier: CC0-1.0
#ifndef CALAMARES_VERSION_H
#define CALAMARES_VERSION_H

#define CALAMARES_ORGANIZATION_NAME "Calamares"
#define CALAMARES_ORGANIZATION_DOMAIN "github.com/calamares"
#define CALAMARES_APPLICATION_NAME "Calamares"
#define CALAMARES_VERSION "3.2.61"
#define CALAMARES_VERSION_SHORT "3.2.61"

#define CALAMARES_VERSION_MAJOR "3"
#define CALAMARES_VERSION_MINOR "2"
#define CALAMARES_VERSION_PATCH "61"
/* #undef CALAMARES_VERSION_RC */

#define CALAMARES_TRANSLATION_LANGUAGES "ar;as;ast;az;az_AZ;be;bg;bn;ca;ca@valencia;cs_CZ;da;de;el;en;en_GB;eo;es;es_MX;et;eu;fa;fi_FI;fr;fur;gl;he;hi;hr;hu;id;is;it_IT;ja;ko;lt;ml;mr;nb;nl;oc;pl;pt_BR;pt_PT;ro;ru;si;sk;sl;sq;sr;sr@latin;sv;tg;th;tr_TR;uk;uz;vi;zh_CN;zh_TW"

#endif  // CALAMARES_VERSION_H
